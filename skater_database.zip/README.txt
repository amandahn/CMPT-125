CMPT 125 Assignment 5
=====================

Amanda Ngo
ahn9@sfu.ca
301433193

Limitations
-----------

The database.txt only includes medals earned since 2010 and no previous medals,
so not all of a skaters medals are counted. For example, Mao Asada won the 
World Championships in 2008, but this is not included in her total number of 
medals. 

Skaters with special characters/accent in their names have these characters 
absent for simplicities sake.

As there are only two disciplines in the database, I implemented a sort by
discipline function instead of sorting the disciplines alphabetically. 

Known Bugs
----------

Extra Features
--------------

Menu has an option to display skaters by country/discipline and
delete skaters by country/discipline.

Information about medalists was taken from here: 
https://en.wikipedia.org/wiki/World_Figure_Skating_Championships

